/*Bhagyashree Narayan Shinde
 * student id:1001552353
 */

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*Drop table `dictionary`;*/

CREATE TABLE IF NOT EXISTS `dictionary` (
  `input_word` varchar(256) NOT NULL,
  `Value` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



INSERT INTO `dictionary` (`input_word`, `Value`) VALUES
('test', ' trial,examination,experiment,assay,try,proof'),
('Brave', 'courageous,fearless,dauntless,intrepid,plucky,daring'),
('Calm', 'quiet,peaceful,still,tranquil,mild,serene,smooth,composed'),
('Dangerous', 'perilous,hazardous,risky,uncertain,unsafe'),
('Decide', 'determine,settle,choose,resolve'),
('Eager', 'keen,fervent,enthusiastic,involved,interested,alive to'),
('Explain', 'elaborate,clarify,define,interpret,justify,account for'),
('Wrong', 'incorrect,inaccurate,mistaken,erroneous,improper'),
('Valid', 'authorized,legitimate');



/*INSERT INTO `dictionary` (`input_word`, `Value`) VALUES ('Come','advance, approach, arrive, near, reach'),
 * ('Run','dash, escape, elope, flee, hasten, hurry, race, rush, speed, sprint'),
 * ('Hurry','rush, run, speed, race, hasten, urge, accelerate, bustle'),
 * ('Hide','conceal, cover, mask, cloak, camouflage, screen, shroud, veil'),
 * ('Destroy','ruin, demolish, raze, waste, kill, slay, end, extinguish'),
 * ('Kill','slay, execute, assassinate, murder, destroy, cancel, abolish'),
 * ('Show ','display, exhibit, present, note, point to, indicate, explain, reveal, prove, demonstrate, expose'),
 * ('Break ','fracture, rupture, shatter, smash, wreck, crash, demolish, atomize');


 */
/*
References
//https://github.com/sumanthl158/Thesaurus/
*/