/**
 * Bhagyashree Narayan Shinde
 * student id:1001552353
 * Server class processes client request and 
 * provides response after processing request.
 */
package com.client.server;

import java.sql.Connection;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.net.*;
import java.sql.*;
import javax.swing.*;

public class Server 
{
	private int port = 2278;//Port number on which socket runs
	private ServerSocket st = null;//It is an reference/object of ServerSocket class used which waits for requests & performs some operation based on that request. 
	private Socket clientSocket; //declaring socket variable for accepting client
	private JTextArea serverSideLogs; //Here UI element i.e textarea variable is declared which decides the area for text in UI
	private JFrame serverWindowSize;//To create framed window for UI.

	String clientNo;
	Integer counter=0;//for client no.
	/*
	 * Below method is called when instance of class or object is created in order to establish database connectivity
	 */
	private Connection getConnection() throws Exception
	{   //Declaration of database properties
		Connection con = null;//Initialization of Connection object to null so that it won't have any garbage or unexpected values;
		String url = "jdbc:mysql://localhost:3306/";//Url lets program know data source to be connected to.
		String db = "mysql";//Name of the database that is being used
		String driver = "com.mysql.jdbc.Driver";//Driver required for database connectivity
		String username = "root";//Username of MYSQL account
		String pass = "shree";//Password of MYSQL account
		try
		{
			Class.forName(driver);//causes driver to load dynamically at runtime
			con = DriverManager.getConnection(url + db, username, pass);//Connects to data source specified by url using account credentials ie.username,password.
		}
		catch (Exception e)
		{
			e.printStackTrace();//used for debugging  and tracking DB errors in order to resolve them
			throw new Exception("Error with database connection");//If a classes such as DriverManager class is not loaded or found, then exception that has raised is managed by this catch block
			
	}
	
		return con;//Connection object is returned.
	}


	/*
	 * Method for server server Logs GUI
	 */
	public void createServerGUI()
	{
		
			serverWindowSize = new JFrame("Server monitor");//Setting the name for frame or window 
			serverWindowSize.setSize(680,750);//setting size of window
			serverWindowSize.getContentPane().setLayout(null);//setting layout 
			serverWindowSize.getContentPane().setBackground(new Color(205,205,195));//setting background color to frame/window.
			serverWindowSize.getContentPane().setForeground(Color.white);
			serverWindowSize.setResizable(false);//Window set to non-resizeable
			serverWindowSize.setLocationRelativeTo(null);//Window is non-relative to location

			serverSideLogs = new JTextArea(30,30);//Textarea size set to length=30,breadth=30
			serverSideLogs.setEditable(false);//Textarea is set as non-editable
			JScrollPane scrollserverWindowSize = new JScrollPane(serverSideLogs);//ScrollPane is added to text area
			scrollserverWindowSize.setBounds(10, 10, 652, 600);//Boundaries of window are set
			serverWindowSize.add(scrollserverWindowSize);//adding scrollPane to window/frame.

			JButton exitButton = new JButton("EXIT");//exit button is defined with name on button as "EXIT"


			exitButton.setBounds(275, 625, 150, 50);//(x,y,width,height) to specify the position and size of a GUI component as layout is set to null
			serverWindowSize.getContentPane().add(exitButton);//exit button is added to frame/window i.e to UI
			exitButton.addActionListener(new ActionListener() {//actioListener is added to handle the button actions such as button click.
					public void actionPerformed(ActionEvent e)//method defines action to be performed on clicking
					{
						System.exit(0);//Action taken will be exiting application and closing connection with server i.e shutting down system normally as status code=0
					}
			});
			serverWindowSize.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			serverWindowSize.setVisible(true);//setting visibility to true allows user to view serverWindow
			executeServer();//call to startServer method which creates server socket
		
	
	}
	/*
	 * Starts socket server and listen for client input 
	 */
	public void executeServer()
	{
		try//for handling exception while creating socket and establishing connectivity
		{
			serverSideLogs.append("Connecting to port " + port + " ....\n");//displaying connection details such as port number in log screen by apppending it into log screen of server
			st = new ServerSocket(port);//server socket created on port number 2278
			serverSideLogs.append("Server is now running ..\n");//let's us now that socket is created successfully and server is in running state by appending/adding this message to log screen
			
			while(true)//if there's no exception
			{
				
				clientSocket = st.accept();//waits until a connection or a client is found. If client is found then accept() function returns a local socket which is connected to another socket at the client which is given to clientSocket.
				counter++;
				 clientNo=counter.toString();
				 serverSideLogs.append("\nclient "+clientNo+" connected");
				SocketHandler client_s = new SocketHandler(clientSocket);//clientSocket is given to Socket Handler class for reading data given by client socket
				client_s.start();//Initiates client socket handler
			}
			
		}
		catch (Exception e)
		{
			serverSideLogs.append("\n"+e.getMessage());//messages are appended to log screen if any error occurs so as to debug
			e.printStackTrace();//used for debugging  and tracking connectivity errors in order to resolve them
		}
     
	}
	
	/*
	 * Reads data from client side using thread and search for the synonym in database,
	 * sends back the synonym for selected word as response. 
	 */
	private class SocketHandler extends Thread//socketHandler class extends thread for creating thread for each client in order to handle clients individually by each thread
	{
		private Socket clientSocket;

		public SocketHandler(Socket clientSocket)
		{            
			super("socketHandler");//parent constructor of socketHandler class is called as it is parameterized constructor and needs to be called explicitly if we have socket handler class
			this.clientSocket = clientSocket;
		}

		public void run()//code to run on thread which is associated with client
		{
			try//for handling IOExceptions
			{
				BufferedReader streamIn = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));//reads data on socket received from client side
				PrintStream streamOut = new PrintStream(clientSocket.getOutputStream(), true);//for writing data on socket that binds client
				while(true){
					String clientWord = streamIn.readLine();//reads object from buffered reader line by line and stores it in clientWord variable i.e it reads the word sent by client for finding synonym 
					StringBuilder synonmys=null;//synonym variable intialized to null so that it won't have garbage or undesired values
					StringBuilder userGUIOutput;//
					/*
					 *  
					 */
					if(clientWord.equalsIgnoreCase("null"))/*If no word is selected on client or 
						 * if the word is not found on database,
						 *  nothing is appended to the string which is sent  
						 *to client.
						 */
					{
						userGUIOutput=new StringBuilder("0");
					}
					else
					{
						synonmys= findSynonyms(clientWord.trim());/*
						*trim() removes leading and trailing whitespaces which might be there while selecting word on client side
						*calls getSynonyms method which executes select query on DB in order to find synonyms for clientWord
						*And the synonym returned by this method is stored in synonyms variable
						*/
						if (synonmys!=null)//if synonyms are found in DB
						{
							userGUIOutput=new StringBuilder(synonmys);//StringBUilder is created which contains string objects treated like variable length array
						}
						else
						{
							userGUIOutput=new StringBuilder("");//if synonyms are not found set string object as null or " "
						}
					}	
					streamOut.println(userGUIOutput);//writing response on client socket
					//Display the selected word on server GUI
					if(clientWord.equalsIgnoreCase("null"))
					{
						 serverSideLogs.append("\nSelected word : No word selected");// to keep track of logs
					}
					else
					{
//						String clientNo=counter.toString();
//						serverSideLogs.append("\nclient "+clientNo+" connected");//To identify which client is connected.
						serverSideLogs.append("\nSelected word from client"+clientNo+": "+clientWord);// to keep tack of logs
					}
					
				}
			}
			catch(Exception e)
			{
				serverSideLogs.append("\n"+e.getMessage());//to know the error while processing client request,error message is printed on text area 
			}
			finally
			{
				try// Necessary for handling IOEXxceptions
				{
					clientSocket.close(); //closing socket after processing client request and sending response to server
				}
				catch(IOException e){
					serverSideLogs.append("\n"+e.getMessage());//to know the error occured while closing client socket,error message is printed on text area
				}
			}
		}
	}


	/*
	 * Below method returns the Synonyms for input word
	 */
	public StringBuilder findSynonyms(String clientWord) throws Exception//code for finding synonym of client word in db and throws exception in order to handle SQL Exceptions and close connection after synonym is retreived
	{
		StringBuilder synonym = null;
		Statement st = null;
		ResultSet res;
		try
		{
			
			st = getConnection().createStatement();//creating instance statement to execute query
			//Querying to search the synonyms in database for the selected word
			 
			res = st.executeQuery("SELECT * FROM  dictionary where input_word ='"+ clientWord + "'");//executing query and stores result in ResultSet objectres
			
			while (res.next())//reading ResultSet objects
				synonym = new StringBuilder(res.getString("value"));//adding synonyms to StringBuilder object which acts as variable length array
			
			if(synonym==null)//checks if synonyms doesn't exists for given word in DB  
			{
				//System.out.println("In ");//debugging
				st.executeUpdate("INSERT INTO `dictionary` (`input_word`, `Value`) VALUES ('"+clientWord+"','');");//if word doesn't exists in DB,word is added in DB.
			}
		}
		catch (Exception s)
		{
			throw new Exception("Error with database!");//Handles MYSQL exception
		}
		finally//releasing resources in final block
		{
			try
			{
				if(st!=null)
					st.close();//closing connection and releasing resources after processing client request
			}
		
				
			
			catch (SQLException e)
			{
				e.printStackTrace();//used to backtack errors if occur
			}
		}
		return synonym;
	}
	public static void main(String[] args) {
	
		Server server = new Server();
		server.createServerGUI();//call to create server GUI
		try{
		server.getConnection();//colsing connection and releasing resources
		}
		catch(Exception e1){
			
			e1.printStackTrace();//used to backtrack errors if occur while closing connection 
		}
		
	}
}


/*References 
 * below are the links using which this project is developed
 * https://github.com/sumanthl158/Thesaurus/blob/master/src/com/client/server/Server.java/

https://github.com/sumanthl158/Thesaurus/blob/master/src/com/client/server/Client.java/

http://www.codingdevil.com/2014/02/simple-chat-application-using-java-socket-programming-2.html/

https://stackoverflow.com/questions/42706914/multi-threaded-gui-java-socket-chat-application/

https://stackoverflow.com/questions/
 
*/