/**
 * Bhagyashree Narayan Shinde
 * student id:1001552353
 *
 * Client class provides user interface to enter
 * the text and selecting a word for Synonyms
 * Used swings Jframe for the Client interface 
 * 
 *
 */
package com.client.server;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.*;

import java.net.*;

import java.sql.SQLException;
import javax.swing.*;

import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

public class Client implements WindowListener //Interface windowListner is used to receive and process window events such window close,active,etc.
{
	private int port = 2278;//port number on which client will connect to server
	private String host="localhost";//currently host is localhost for remote client localhost can be replaced with host IP e.g.127.0.0.1
	JTextArea clientInputArea;//declaring object for creating text area in GUI and declared globally as it is used in different methods.
	private JList jList;//Object list of objects received from server ,JList allows to access one or more object and operate on them.
	JFrame clientWindow;//as JFrame object is accessed in various methods ,hence it is declared global level
	private PrintStream streamOut;//PrintStream allows to print data representations
	JLabel clientInputAreaLabel,synonymAreaLabel;//JLabel object declaration-allows to add label in GUI/Frame,in program two labels are used.
	JScrollPane scrollclientInputArea,scrollSynonymDispArea;//JScrollPane object declaration-allows to view data properly if textarea or display area isn't large enough to view all data , then scrollbar is used to view data that doesn't fit in area.
	int start,end,length;//Variables required while operating of object list i.e jList
	String totalInput,selectedInput;//totalInput string keeps track of total words in clientInputArea and selectedInput of the word selected to find synonym.

	/*
	 * Below method is used to create client side GUI,method is called as soon as the client class is loaded.
	 * GUI is developed using Java swing
	 */
	public void ClientGUI()//client GUI
	{
		try// for handling client socket creation exceptions in executeClient() method
		{
			clientWindow = new JFrame("Client GUI");
			JButton sendServerBtn = new JButton("Find Synonyms");//button is declared which on clicking finds synonyms.
			clientWindow.setSize(676,730);//setSize(int width,int height) this function sets window of width 676 and height 730
			clientWindow.getContentPane().setLayout(null);//as layout is set to null,there's no layout for window
			clientWindow.getContentPane().setBackground(new Color(205,205,195));//Background color set to grey after mixing shades of(R,G,B)
			clientWindow.getContentPane().setForeground(Color.white);//Foreground color i.e clientInput area and synonym display area are set to white


			

			clientInputAreaLabel = new JLabel("Enter word and select the word of which you wanna find synonyms ");//label is created inorder to inform client how to use GUI and output
			clientWindow.getContentPane().add(clientInputAreaLabel);//label element is added to Frame/window
			clientInputArea = new JTextArea(40,40);//textarea is defined and it's dimensions
			scrollclientInputArea = new JScrollPane(clientInputArea);//scroller is attached to client input area
			scrollclientInputArea.setBounds(10,30,650,190);//location and width,height of input area is fixed (x-co-ordinate,y-co-ordinate,width,height)
			clientWindow.add(scrollclientInputArea);//client input area element is added to frame/window
			clientInputAreaLabel.setForeground(Color.red);//Label color is set to red

			jList=new JList();//defind for stoeing server objects

			synonymAreaLabel = new JLabel("Following are synonyms for selected word");//label created for display area
			clientWindow.getContentPane().add(synonymAreaLabel);//label adde to frame/window
			scrollSynonymDispArea = new JScrollPane(jList);//scroll bar is scrolled over jList i.e on server response object
			scrollSynonymDispArea.setBounds(50, 500, 600, 100);//location and width,height of input area is fixed (x-co-ordinate,y-co-ordinate,width,height)
			
			clientWindow.add(scrollSynonymDispArea);//synonym display area is added to Frame/window
			synonymAreaLabel.setForeground(Color.red);//Label color is set to red

			clientWindow.getContentPane().add(sendServerBtn);//Find synonym button which on clicking send s client request to server is added to Frame/window

			
			sendServerBtn.setBounds(250,320,165,34);//location and width,height of input area is fixed (x-co-ordinate,y-co-ordinate,width,height) for button.Helpful to manage UI.
			clientInputAreaLabel.setBounds(50,210,500,50);//same as above but to fix location and size of client Input area label
			synonymAreaLabel.setBounds(50,440,500,50);//same as above but to fix location and size of synonym display area label.



			JButton exitButton = new JButton("EXIT");//exit button is defined with name on button as "EXIT"


			exitButton.setBounds(275, 625, 150, 50);//(x,y,width,height) to specify the position and size of a GUI component as layout is set to null
			clientWindow.getContentPane().add(exitButton);//exit button is added to frame/window i.e to UI
			exitButton.addActionListener(new ActionListener() {//actioListener is added to handle the button actions such as button click.
					public void actionPerformed(ActionEvent e)//method defines action to be performed on clicking
					{
						System.exit(0);//Action taken will be exiting application and closing connection with server i.e shutting down system normally as status code=0
					}
			});


			sendServerBtn.addActionListener(new ActionListener()//actioListener is added to handle the button actions such as button click.

			{
				public void actionPerformed(ActionEvent e)//method specifies the task to be performed on clicking button
				{
					selectedInput=clientInputArea.getSelectedText();//retrieves selected input from inputarea feild and stores it in selectedInput varaiable for sending it to server
					
					/*validate the entered word so user doesn't enter numbers or invalid words*/
					if(selectedInput.matches("[a-zA-Z]*")==true)
					{
					streamOut.println(selectedInput);//prints/sends the selectedInput retrieved previously to the socket on which we have server connection
					
					start=clientInputArea.getSelectionStart();//used to retrieve start position of characters in client input area
					
					end=clientInputArea.getSelectionEnd();//used to retrieve end position of characters in client input area
					
					length=clientInputArea.getText().length();//Finds length  or count number of characters in client input area and stores it in length varaiable for future use
					
					totalInput=clientInputArea.getText();//To retrieve charsequence in client input area

					}
					else{
						JOptionPane.showMessageDialog(clientWindow,"Please enter valid Word","Result",JOptionPane.ERROR_MESSAGE);
					}
				}
			});
			clientWindow.setVisible(true);//setting visibility to true allows user to view clientWindow
			
			clientWindow.setDefaultCloseOperation(JFrame.DO_NOTHING_ON_CLOSE);//commands window or UI  to do nothing on closing window 
			
			clientWindow.addWindowListener(this);//adding window listener interface to our JFrame to receive and manage window events
			
			executeClient();//call to executeClient in order to create client socket and achieve connectivity with server
		}
		catch (Exception e)
		{
			e.printStackTrace();//used by me for debugging using console and backtracing errors
		}
	}

	/*
	 * Below method creates a client socket and binds it with server over a port
	 */
	public void executeClient() throws Exception
	{
		try
		{
			Socket clientSocket = new Socket(host, port);//creates client socket with given gost and port i.e host=localhost & port=2278
			
			BufferedReader streamIn = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));//reads data from socket sent by srever and stores it in streamIn
			
			streamOut = new PrintStream(clientSocket.getOutputStream(), true);//output stream object created to send data to server.

			while(true)
			{
				String serverResponse = streamIn.readLine();//reads server response line by line
				if(serverResponse.equalsIgnoreCase(""))//checks if object or object list sent by server is empty (case insensitive)
				{
					Object[] objectServer=new Object[0]; //array object set to size 0

						JOptionPane.showMessageDialog(clientWindow,"No synonym found for the selected word.But the word has added to Database!","Result",JOptionPane.ERROR_MESSAGE);
						//message is displayed using dialog box to client
						
						jList.setListData(objectServer);//jList set to objectServer inorder to iterate over list of objects

				}
				/*
				 * If the no word is selected,
				 * then display appropriate message to user and reset synonym area
				 */
				else if((serverResponse.equalsIgnoreCase("0")))//checks if object or object list sent by server is null (case insensitive)
				{
					Object[] objectServer=new Object[0]; 

					
						JOptionPane.showMessageDialog(clientWindow,"Please select a word to find the synonyms","Result",JOptionPane.ERROR_MESSAGE);
						//message is displayed using dialog box to client
						
						jList.setListData(objectServer);//jLlist set to objectServer inorder to iterate over list of objects
				
					
				}
				/*
				 * If synonyms are found then data retreived from database by server and received by client is modified in
				 *  user readable format and attached to jList
				 * so that user can select synonym for selected word.
				 */
				else
				{
					String[] synonyms=serverResponse.split(",");//objects are separated  by comma
					
					jList.setListData(synonyms);//list data is set to the data that was separated in previous step in order to process data

					jList.addListSelectionListener(new ListSelectionListener()//for going through list i.e basically used when selection in list keeps changing the text in  client input area changes
					{ 
						public void valueChanged(ListSelectionEvent e)//Action to be performed if selection of word in list is changed i.e while traversing through list 
						{
							JList list = (JList) e.getSource(); //returns object on which selection or iteration is done initially and stored in another jList

							String selectedValue = (String) list.getSelectedValue(); //the object which is currently selected in JLiist is stored in selected value

							try
							{
								String before=totalInput.substring(0,start);//initializing start of string or data to be displayed
								
								String after="";//terminating string
								after=totalInput.substring(end,length);//substring i.e synonyms are stored in after variable
								String finalResult;
								if(selectedValue==null  || selectedValue.equalsIgnoreCase("null"))//if there is no object in JList thst is being selected
									
									finalResult=totalInput;//finalresult as totalinput
								
								else
									
									finalResult=before+selectedValue+after;//else final result to be displayed in user readable format will be combination of string=before+selectedvalue+after
								
								clientInputArea.setText(finalResult);//displays text to client in client Input area as we go selecting through list in second text area
							}
							catch (Exception e1)
							{
								e1.printStackTrace();//used by me for debugging using console and backtracking errors
							}

						} 
					});
				}
			}
		}
		catch (Exception e)
		{
			JOptionPane.showMessageDialog(clientWindow,"Unable to Connect server, please try again later","ERROR",JOptionPane.ERROR_MESSAGE);
			//message is displayed using dialog box to client if client is not able to connect to server or if server is not in running state
			
			System.exit(0);//if client is unable to connect to server or if server is not in running state then client application exits itself.
		}
	}

	/*
	 * (non-Javadoc)
	 * @see java.awt.event.WindowListener#windowClosing(java.awt.event.WindowEvent)
	 * closes the client window on click of "X"
	 */
	public void windowClosing(WindowEvent e)
	{
		clientWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public void windowOpened(WindowEvent e) {}  //methods of windows listener interface that needs to be overwritten in order to receive window events and process them
	public void windowClosed(WindowEvent e) {}//same as above
	public void windowIconified(WindowEvent e) {}// same as above
	public void windowDeiconified(WindowEvent e) {}// same as above
	public void windowActivated(WindowEvent e) {}//same as above
	public void windowDeactivated(WindowEvent e) {}//same as above

	public static void main(String[] args){
		new Client().ClientGUI();//method is invoked to open client window which in turn after loading GUI calls executeClient() method which binds client to server.
	}
}

/*References
 * below are the links using which this project is developed
 * https://github.com/sumanthl158/Thesaurus/blob/master/src/com/client/server/Server.java/

https://github.com/sumanthl158/Thesaurus/blob/master/src/com/client/server/Client.java/

http://www.codingdevil.com/2014/02/simple-chat-application-using-java-socket-programming-2.html/

https://stackoverflow.com/questions/42706914/multi-threaded-gui-java-socket-chat-application/

https://stackoverflow.com/questions/
 
*/